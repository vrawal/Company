﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestCompany.BusinessLogic;

namespace TestCompany.Test
{
    [TestClass]
    public class NameServiceTest
    {
        #region GetLines

        [TestMethod]
        public void GetLines_Returns_CorrectData()
        {
            var nameService = new NameService(new TestContext());

            var output = nameService.GetLines()
                .Split(new[] {"\r\n", "\n"}, StringSplitOptions.None);

            Assert.AreEqual(output[0], "Brown,2");
            Assert.AreEqual(output[8], "John,1");
        }

        #endregion

        #region ReadLines()

        [TestMethod]
        public void ReadLines_GetsData()
        {
            var nameService = new NameService(new TestContext());
            var data = nameService.ReadLines();
            Assert.AreEqual(data.Count, 9);
        }

        [TestMethod]
        public void ReadLines_Skips_FirstRow_OrderBy_Name()
        {
            var nameService = new NameService(new TestContext());
            var data = nameService.ReadLines();
            Assert.AreEqual(data.First().Name, "Brown");
            Assert.AreEqual(data.First().Frequency, 2);
        }

        #endregion

        #region MapAddress

        [TestMethod]
        public void MapAddress_Maps_CorrectData()
        {
            var nameService = new NameService(new TestContext());
            var jimmy = nameService.MapNames(GetJimmyAddress());
            Assert.AreEqual(jimmy.Name.First(), "Jimmy");
            Assert.AreEqual(jimmy.Name.Last(), " Smith");
        }


        private IReadOnlyList<string> GetJimmyAddress()
        {
            return new List<string>
            {
                "Jimmy",
                " Smith",
                "102 Long Lane",
                "29384857"
            };
        }

        #endregion
    }
}