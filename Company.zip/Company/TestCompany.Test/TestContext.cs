﻿using TestCompany.DataLayer;

namespace TestCompany.Test
{
    internal class TestContext : IDataContext
    {
        public string[] Read()
        {
            const string line1 = "FirstName,LastName,Address,PhoneNumber";
            const string line2 = "Jimmy,Smith,102 Long Lane,29384857";
            const string line3 = "Clive,Owen,65 Ambling Way,31214788";
            const string line4 = "James,Brown,82 Stewart St,32114566";
            const string line5 = "Graham,Howe,12 Howard St,8766556";
            const string line6 = "John,Howe,78 Short Lane,29384857";
            const string line7 = "Clive,Smith,49 Sutherland St,31214788";
            const string line8 = "James,Owen,8 Crimson Rd,32114566";
            const string line9 = "Graham,Brown,94 Roland St,8766556";

            return new[] {line1, line2, line3, line4, line5, line6, line7, line8, line9};
        }
    }
}