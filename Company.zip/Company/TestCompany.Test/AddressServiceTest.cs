﻿using System;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using TestCompany.BusinessLogic;

namespace TestCompany.Test
{
    [TestClass]
    public class AddressServiceTest
    {
        #region ReadLines()

        [TestMethod]
        public void ReadLines_GetsData()
        {
            var addressService = new AddressService(new TestContext());
            var data = addressService.ReadLines();
            Assert.AreEqual(data.Count, 8);
        }

        [TestMethod]
        public void ReadLines_Skips_FirstRow_OrderBy_Name()
        {
            var addressService = new AddressService(new TestContext());
            var data = addressService.ReadLines();
            Assert.AreEqual(data.First().Name, "Ambling Way");
        }

        #endregion

        #region MapAddress

        [TestMethod]
        public void MapAddress_Maps_CorrectData()
        {
            var addressService = new AddressService(new TestContext());
            var jimmy = addressService.MapAddress(GetJimmyAddress());
            Assert.AreEqual(jimmy.Name, "Long Lane");
            Assert.AreEqual(jimmy.Number, "102");
        }


        private IReadOnlyList<string> GetJimmyAddress()
        {
            return new List<string>
            {
                "Jimmy",
                " Smith",
                "102 Long Lane",
                "29384857"
            };
        }

        #endregion

        #region GetLines

        [TestMethod]
        public void GetLines_Returns_CorrectData()
        {
            var addressService = new AddressService(new TestContext());

            var output = addressService.GetLines()
                .Split(new string[] { "\r\n", "\n" }, StringSplitOptions.None);

            Assert.AreEqual(output[0], "65 Ambling Way");
            Assert.AreEqual(output[7], "49 Sutherland St");
            
        }

        
        #endregion


    }
}