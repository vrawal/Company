﻿using Autofac;
using TestCompany.BusinessLogic;
using TestCompany.BusinessLogic.Base;
using TestCompany.DataLayer;

namespace TestCompany
{
    public class IoCConfig
    {
        public static IContainer Configure()
        {
            var builder = new ContainerBuilder();
            builder.RegisterType<ORM>().As<IDataContext>();
            builder.RegisterType<AddressService>().As<IAddressService>();
            builder.RegisterType<NameService>().As<INameService>();
            return builder.Build();
        }
    }
}