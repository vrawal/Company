﻿using System;
using System.IO;
using Autofac;
using TestCompany.BusinessLogic.Base;
using Config = System.Configuration.ConfigurationManager;

namespace TestCompany
{
    public class Program
    {
        private static void Main(string[] args)
        {
            //resolve services and call methods on them to get data
            using (var scope = IoCConfig.Configure().BeginLifetimeScope())
            {
                File.WriteAllText(Config.AppSettings["Name"], scope.Resolve<INameService>().GetLines());
                File.WriteAllText(Config.AppSettings["Address"], scope.Resolve<IAddressService>().GetLines());
            }

            Console.WriteLine("Done. Check Names.txt and Address.txt");
            Console.ReadLine();
        }
    }
}