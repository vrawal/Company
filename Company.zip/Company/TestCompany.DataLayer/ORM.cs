﻿using System;
using System.IO;

namespace TestCompany.DataLayer
{
    //Our own datasource
    public class ORM :IDataContext
    {
        public string[] Read()
        {
            const string path = "data.csv";

            if (!File.Exists(path))
            {
                throw new Exception("File doesnt exist.");
            }

            try
            {
                return File.ReadAllLines(path);
            }
            catch (Exception)
            {
                throw new Exception("Unable to read file.");
            }
        }
    }

    //Any Datacontext

}