﻿namespace TestCompany.DataLayer
{
    public interface IDataContext
    {
        string[] Read();
    }
}