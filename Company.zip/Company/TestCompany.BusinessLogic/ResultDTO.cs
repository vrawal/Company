namespace TestCompany.BusinessLogic
{
    public class ResultDTO
    {
        public string Name { get; set; }
        public int Frequency { get; set; }
    }
}