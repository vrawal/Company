﻿using System;
using System.Collections.Generic;
using System.Linq;
using TestCompany.BusinessLogic.Base;
using TestCompany.DataLayer;

namespace TestCompany.BusinessLogic
{
    public class AddressService : IAddressService
    {
        public AddressService(IDataContext context)
        {
            Context = context;
        }

        public IDataContext Context { get; set; }

        public string GetLines()
        {
            //return a string that can be outputed
            return ReadLines()
                .Aggregate("", (current, address) => current + address.Number + " " + address.Name + Environment.NewLine);
        }

        public List<AddressDTO> ReadLines()
        {
            var header = 0;

            try
            {
                //Get values from data layer
                return (from line in Context.Read() where header++ > 0 select MapAddress(line.Split(',')))
                    .OrderBy(x => x.Name)
                    .ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        //Address parser
        public AddressDTO MapAddress(IReadOnlyList<string> columns)
        {
            var address = columns[2].Split(' ');

            return new AddressDTO
            {
                Number = address[0],
                Name = address[1] + " " + address[2]
            };
        }
    }
}