﻿namespace TestCompany.BusinessLogic
{
    public class AddressDTO
    {
        public string Number { get; set; }
        public string Name { get; set; }
    }
}