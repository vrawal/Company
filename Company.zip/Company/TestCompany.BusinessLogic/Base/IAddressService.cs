﻿namespace TestCompany.BusinessLogic.Base
{
    public interface IAddressService : IService
    {
        string GetLines();
    }
}