﻿namespace TestCompany.BusinessLogic.Base
{
    public interface INameService : IService
    {
        string GetLines();
    }
}