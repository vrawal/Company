﻿namespace TestCompany.BusinessLogic.Base
{
    public interface IService 
    {
    }
}