﻿using System;
using System.Collections.Generic;
using System.Linq;
using TestCompany.BusinessLogic.Base;
using TestCompany.DataLayer;

namespace TestCompany.BusinessLogic
{
    public class NameService : INameService
    {
        public NameService(IDataContext context)
        {
            Context = context;
        }

        public IDataContext Context { get; set; }

        public string GetLines()
        {
            //return a string that can be outputed 
            return ReadLines()
                .Aggregate("",
                    (current, resultDto) => current + resultDto.Name + "," + resultDto.Frequency + Environment.NewLine);
        }

        public List<ResultDTO> ReadLines()
        {
            var header = 0;
            var results = new List<ResultDTO>();

            var names = new List<NameDTO>();
            try
            {
                //get names
                names.AddRange(from line in Context.Read() where header++ > 0 select MapNames(line.Split(',')));

                //create a query based on logic
                var query = names
                    .SelectMany(n => n.Name)
                    .GroupBy(n => n, (x, y) => new {Name = x, Count = y.Count()});

                //create a result object
                results.AddRange(query.Select(result => new ResultDTO
                {
                    Frequency = result.Count,
                    Name = result.Name
                }));

                //return result object based on business rule ie sort order in this case
                return results.OrderByDescending(x => x.Frequency).ThenBy(y => y.Name).ToList();
            }
            catch (Exception)
            {
                throw;
            }
        }

        public NameDTO MapNames(IReadOnlyList<string> columns)
        {
            return new NameDTO
            {
                Name = new HashSet<string> {columns[0], columns[1]}
            };
        }
    }
}