﻿using System.Collections.Generic;

namespace TestCompany.BusinessLogic
{
    public class NameDTO
    {
        public HashSet<string> Name;
    }
}